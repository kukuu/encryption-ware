In this example we display this data in two ways:
 1. as two overlaid line charts using two separate axes, or
 2. as a channel display where the user instead scrubs the data to see the value.

It demonstrates:
 * Broken lines for missing data
 * Pan and zoom over the dataset: Drag to pan, scrollwheel to zoom
 * Brushing over an elevation chart: drag and resize the blue rectangle to pan and zoom
 * Hover info boxes, in the multi-axis mode
 * Channel display using LabelAxis and ValueAxis
