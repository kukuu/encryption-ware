
[http://climate.nasa.gov/vital-signs/global-temperature/
](http://climate.nasa.gov/vital-signs/global-temperature/)

Data source: NASA's Goddard Institute for Space Studies (GISS).
