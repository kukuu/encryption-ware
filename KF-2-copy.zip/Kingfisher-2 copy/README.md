
### Run commands
Open two more command prompts / terminals windows (with administrator rights) 

Navigate to this folder

1. run : *NPM install*

2. After installating all dependencies, navigate to the  "server" folder and type

run : *node server*

When server starts running, then

3. run : *NPM run start*

