const express = require('express');
const bodyParser = require('body-parser');
const passport = require('passport');
const config = require('../config');
const path = require('path');





// connect to the database and load models
require('./models').connect(config.dbUri);

const app = express();
const clientPath = path.join(__dirname, '../client/');
app.use('/public', express.static(clientPath + 'dist'));
app.use('/orgional', express.static(clientPath + 'src'));

// tell the app to parse HTTP body messages
app.use(bodyParser.urlencoded({ extended: false }));
// pass the passport middleware
app.use(passport.initialize());

// load passport strategies
const localSignupStrategy = require('./passport/local-signup');
const localLoginStrategy = require('./passport/local-login');
passport.use('local-signup', localSignupStrategy);
passport.use('local-login', localLoginStrategy);

// pass the authorization checker middleware
const authCheckMiddleware = require('./middleware/auth-check');
app.use('/api', authCheckMiddleware);

// routes
const authRoutes = require('./routes/auth');
const apiRoutes = require('./routes/api');

app.use('/auth', authRoutes);
app.use('/api', apiRoutes);



//Begin Authy-2FA:
//THIS IS FOR INJECTING AUTHY-2FA - leveraged from "kingfisher/Authy-2fa": 
//From server folder: /Controller,  config.js
// saved the controller as  @controllers in /server/controllers
//saved config.js as @config.js saved to server/@config.js
//saved demo.bat and demo.env as @demo.bat and @demo.env  
//at the root level of the application to mirror where they are saved in kingfisher-Authy-2


//npm install 'cookie-parser'
//var cookieParser = require('cookie-parser');

//npm install 'express-session'
//var expressSession = require('express-session');

//npm install 'connect-mongo'
//var mongoStore = require('connect-mongo')({session: expressSession});

//var config = require('./server/config.js');

/* if(!config.API_KEY){
	    console.log("Please set your DEMO_AUTHY_API_KEY environment variable before proceeding.");
	    process.exit(1);
 	}
*/

//app.use(cookieParser());
//app.use(expressSession({'secret': config.SECRET}));

//var router = express.Router();

//var users = require('./server/controllers/users.js');
//This loads all the modules below:sms/voice/verify/onetouchstatus/onetouch


//router.route('/user/register').post(users.register);
//router.route('/logout').get(users.logout);
//router.route('/login').post(users.login);

 /* Authy Authentication API
 */
/*router.route('/authy/sms').post(users.sms);
router.route('/authy/voice').post(users.voice);
router.route('/authy/verify').post(users.verify);
router.route('/authy/onetouchstatus').post(users.checkonetouchstatus);
router.route('/authy/onetouch').post(users.createonetouch);

router.route('/loggedIn').post(users.loggedIn);*/

/**
 * Authy Phone Verification API
 */
/*router.route('/verification/start').post(users.requestPhoneVerification);
router.route('/verification/verify').post(users.verifyPhoneToken);*/

/**
 * Require user to be logged in and authenticated with 2FA
 *
 * @param req
 * @param res
 * @param next
 */

/*function requirePhoneVerification(req, res, next) {
    if (req.session.ph_verified) {
        console.log("Phone Verified");
        next();
    } else {
        console.log("Phone Not Verified");
        res.redirect("/verification");
    }
}*/

/**
 * Require user to be logged in and authenticated with 2FA
 *
 * @param req
 * @param res
 * @param next
 */
/*function requireLoginAnd2FA(req, res, next) {
    if (req.session.loggedIn && req.session.authy) {
        console.log("RL2FA:  User logged and 2FA");
        next();
    } else if (req.session.loggedIn && !req.session.authy) {
        console.log("RL2FA:  User logged in but no 2FA");
        res.redirect("/2fa");
    } else {
        console.log("RL2FA:  User not logged in.  Redirecting.");
        res.redirect("/"); 
        //res.redirect("/login");

        
    }
}*/


/**
 * Require user to be logged in.
 *
 * @param req
 * @param res
 * @param next
 */
/*function requireLogin(req, res, next) {
    if (req.session.loggedIn) {
        console.log("RL:  User logged in");
        next();
    } else {
        console.log("RL:  User not logged in.  Redirecting.");
        res.redirect("/");
        //res.redirect("/login");
    }
}*/


/**
 * Test for 200 response.  Useful when setting up Authy callback.
 */
/*router.route('/test').post(function(req, res){
    return res.status(200).send({"connected": true});
});*/


/* In the following route setup, 
	A - The protected directory requires two factors for access while the
	B -  2FA directory requires only a login session.
*/

/** A
 * All pages under protected require the user to be both logged in and authenticated via 2FA
 */
/*
	app.all('/protected/*', requireLoginAnd2FA, function (req, res, next) {
    	next();
	})
*/

/** B
 * Require user to be logged in to view 2FA page.
 */
/*
	app.all('/2fa/*', requireLogin, function (req, res, next) {
    	next();
	});
*/

//app.use('/api', router);

//END Authy-2FA









// start the server
app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000 or http://127.0.0.1:3000');
});