import React from "react";

class Dashboard extends React.Component {
  render() {
    const welcomMessage = "Welcome to the dashboard";
    return (
      <header>
        <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
            <div class="navbar-header">
              <a class="navbar-brand" href="#">{welcomMessage}</a>
            </div>
          </div>
        </nav>
      </header>
    );
  }
}

/*
 * To accomodate dashboard  
*/
export default Dashboard;
