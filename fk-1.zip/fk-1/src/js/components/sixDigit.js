import React from 'react';
//import EmailAddress from './EmailAddress';

class Form extends React.Component {
    constructor(props) {
        super(props);
    }

    handleSubmit(e) {
        e.preventDefault();
        console.log('form is valid');
    }

    render() {
        return (
            <div className="form-section">
                <div className="container">
                    <div className="row">
                        <div class="col-md-5 col-md-offset-3">
                            <h1 className="card-heading">Kingfisher</h1>
                            <h3>INTELLIGENT NETWORK SECURITY</h3>
                            <h4>AUTHENTICATION code</h4>
                            <p>Enter the six digit code provided by your 2FA Device</p>
                            <form id="login-form" role="form" onSubmit={this.handleSubmit}>
                                <div class="form-group">
                                    <label for="login-email">Email</label>
                                    <input id="login-email"
                                        class="email form-control input-md"
                                        type="email"
                                        placeholder="Email"
                                    />
                                </div>
                        
                                <div class="form-group">
                                    <div className="pull-left">
                                       // <EmailAddress /> 
                                        <p>demo@example.email.</p>
                                    </div>
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
/*
* This is main body of the page
*/
export default Form;