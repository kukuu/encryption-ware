import React from "react";

class Footer extends React.Component {
  render() {
    return (
      <footer>
        <div className="container">
          <div class="navbar navbar-inner  navbar-fixed-bottom">
            <p class="muted credit">&nbsp;Copyright @2017 , developed and created by Berry Technologies</p>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;