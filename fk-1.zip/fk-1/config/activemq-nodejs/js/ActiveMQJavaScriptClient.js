

(function (_) {

"use strict";

    _.JMSQueueBrowser = function (destination, page, total, _callback) {
        // Constructing initial AJAX Request to get XML data from ActiveMQ
        this.last = page * 100;
        this.first = this.last - 100;


        this.d = {};
        this.destination = "channel://test";
        this.page = page;
        //this.totalPages = t;
        var that = this;
        this.url = "failover:tcp://localhost:61616" + this.destination ;
        

        return {
            req: $.ajax(this.url).
            done(_callback),
            totalPages: total,
            isFirst: function () {
                return (this.getPageNum() == 1);
            },
            empty: function () {
                $("#messages").empty();
                $("#messages").append("<thead>" + "<tr>" +
                 "<th>Message Id</th>" + "<th>Updated Date</th>" +
                  "<th>Published Date</th>" + "<th>Summary</th>" + "<th>Delete</th>" + "</tr>" + this.getMQList() + "<tbody>");
            }


            Paginate: function () {
                try {
                    if (this.isMax()) {
                        throw "This is the last item in the list sorry…";
                    }
                    $("#page table").empty();
                    var start = this.getPageNum();
                    var end = this.getPageNum() + 10;
                    start++;
                    if (end >= this.getTotalPages()) {
                        end = this.getTotalPages();
                    }

                    for (var i = start; i < end + 1; i++) {
                        this.getPageLink(i);
                    }

                    this.moveCurLine(0);

                } catch (err) {}

                //This used to scroll up the page when a user click the button...
                $("body").animate({
                    scrollTop: '0px'
                }, 800);

            } 
    };


    _.QueryStringHelper = {

        getCurrentUrl: function () {
            return window.location.href;
        },
        isQueryStr: function () {
            return this.getCurrentUrl().indexOf("?") != -1;
        },
        getQueryString: function () {
            return this.getCurrentUrl().split("?")[1];
        },
        toJSON: function () {
            var json = {};
            try {
                var keys = this.getQueryString().split("&");
                for (var i = 0, len = keys.length; i < len; i++) {
                    var pair = keys[i].split("=");
                    var pairval = decodeURIComponent(pair[1]);
                    pairval = pairval.replace("+", " ");
                    json[pair[0]] = pairval;
                }
            } catch (err) {}
            return json;
        }
    };

    if (QueryStringHelper.toJSON().page) {
        Number(QueryStringHelper.toJSON().page);
    };

//  JSON.parse(str).value.TotalMessageCount

_.getJMXJSON=function(brokertype, brokername,callback){
    this.bType = brokertype || 'Broker';
    this.bName = brokername || 'localhost';
    this.calli = callback || function(data){
                                    console.log("Total Count of Messages: " + data.value.TotalMessageCount);
                                    data.value.TotalMessageCount;
                                }
    this.url="http://localhost:8161/api/jolokia/read/org.apache.activemq:type="+this.bType+",brokerName="+this.bName;
    return {
            req: $.ajax(this.url).done(callback) ,
            getBrokerType: brokertype ,
            getBrokerName: brokername,
            getMessageCount: 0
    }
}

})(this);