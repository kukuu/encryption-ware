## Instructions to run
1. Navigate to this folder
2. *NPM install*
3. *NPM run dev*
4. Navigate to localhost:8080

When you run the app on the brower, the output would be 

![Alt text](https://raw.githubusercontent.com/amir-saeed/ReactJs/master/Show-bootstrap-modal-on-button-click/output.png?raw=true "Bootstrap modal")

### Dependencies
This project use Babel, webpack, react, react-dom and bootstrap, jquery
