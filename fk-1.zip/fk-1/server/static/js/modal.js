window.onload=function(){
var elem = document.querySelector('.modal');
var opts = {
  showSelector: '.js-modal-show',
  hideSelector: '.js-modal-hide',
  dialogSelector: '.modal__dialog',
  fade: {
    duration: '.2s',
    timingFunction: 'ease'
  }
};
modal(elem, opts);
}