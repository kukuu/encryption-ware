import React  from 'react';



const Dashboard = ({ secretData }) => (
  
  <div>
      <p className="secret"> You should get access to this page only after authentication</p>
        
    </div> 
);



export default Dashboard;
