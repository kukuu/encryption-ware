import React from 'react';

const HomePage = () => (
			<h3>Network Forensic Tool - This is the home page</h3>
);

export default HomePage;
