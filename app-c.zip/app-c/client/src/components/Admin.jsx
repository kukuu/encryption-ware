import React, { PropTypes } from 'react';
import { Link } from 'react-router';




const Admin = ({
  errors,
  successMessage,
  user
}) => (
  
    <h3 className="card-heading">Welcome the Admin Page</h3>
    
);



export default Admin;
